# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
from stripe.params.test_helpers.terminal._reader_present_payment_method_params import (
    ReaderPresentPaymentMethodParams as ReaderPresentPaymentMethodParams,
)
from stripe.params.test_helpers.terminal._reader_succeed_input_collection_params import (
    ReaderSucceedInputCollectionParams as ReaderSucceedInputCollectionParams,
)
from stripe.params.test_helpers.terminal._reader_timeout_input_collection_params import (
    ReaderTimeoutInputCollectionParams as ReaderTimeoutInputCollectionParams,
)
