# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
from stripe._request_options import RequestOptions


class ReaderDeleteParams(RequestOptions):
    pass
