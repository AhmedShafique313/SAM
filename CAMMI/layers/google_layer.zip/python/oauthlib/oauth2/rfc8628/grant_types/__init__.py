from oauthlib.oauth2.rfc8628.grant_types.device_code import DeviceCodeGrant
